<?php $__env->startSection('content'); ?>
    <div class="card col-lg-4 col-md-6 col-sm-12 col-12">
        <div class="card-body">
            <h2 class="card-title text-muted">Mobil</h2>
            <h6 class="card-subtitle mb-2 text-muted">Isi form dibawah ini untuk melanjutkan</h6>
            <hr>
            
            <form action="" class="justify-content-start">
                <div class="input-group">

                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-user-circle"></i></div>
                    </div>
                    <input type="text" class="form-control" id="nama" placeholder="Nama" required>
                </div>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-phone" aria-hidden="true"></i></div>
                    </div>
                    <input type="text" class="form-control" id="no_hp" placeholder="Nomor Telephone" required>
                </div>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-envelope" aria-hidden="true"></i></div>
                    </div>
                    <input type="email" class="form-control" id="email" placeholder="Email" required>
                </div>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-hashtag" aria-hidden="true"></i></div>
                    </div>
                    <input type="text" class="form-control" id="sisa_cicilan" placeholder="Sisa Cicilan (Rp.)" required>
                </div>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-hashtag" aria-hidden="true"></i></div>
                    </div>
                    <input type="text" class="form-control" id="besar_cicilan" placeholder="Besar Cicilan (Rp.)" required>
                </div>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                    </div>
                    <input type="text" class="form-control" id="sisa_waktu" placeholder="Sisa Waktu Cicilan (Bulan)" required>
                </div>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-university" aria-hidden="true"></i></div>
                    </div>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Nama Bank Sebelumnya" required>
                </div>

                <button type="submit" class="btn btn-success">Simpan</button>

                <div class="input-group">
                    <p class="text-muted" style="font-size: 11px; font-weight: bold">Contact Us :</p>
                </div>
                <div class="input-group">
                    <p class="text-muted" style="font-size: 11px; margin-top: -20px; margin-bottom: -30px; font-weight: bold">admin@hijrahkan.com</p>
                </div>
            </form>


        </div>
    </div>
    <!-- Autonumeric js -->
    <script src="https://cdn.jsdelivr.net/npm/autonumeric@4.1.0"></script>
    <script>
        new AutoNumeric('#sisa_cicilan', {
            decimalPlace: '2',
            digitGroupSeparator: '.',
            decimalCharacter: ',',
        });
        new AutoNumeric('#besar_cicilan', {
            decimalPlace: '2',
            digitGroupSeparator: '.',
            decimalCharacter: ',',
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .card{
            margin-top: 15px;
        }

    </style>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fastwork\project-hijrahkan\resources\views/form/mobil.blade.php ENDPATH**/ ?>