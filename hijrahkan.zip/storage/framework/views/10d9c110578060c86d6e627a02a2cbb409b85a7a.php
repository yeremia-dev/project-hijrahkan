<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>
</head>
<body>
<table>
    <thead>
    <tr>
        <th style="font-weight: bold">NO</th>
        <th style="font-weight: bold">NAMA</th>
        <th style="font-weight: bold">NOMOR TELEPHONE</th>
        <th style="font-weight: bold">EMAIL</th>
    </tr>
    </thead>
    <tbody>
    <?php $no = 1 ?>
    <?php $__currentLoopData = $datainfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datainfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($datainfo->nama); ?></td>
            <td><?php echo e($datainfo->nomor_hp); ?></td>
            <td><?php echo e($datainfo->email); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</body>
</html>
<?php /**PATH D:\Miku\project-hijrahkan\resources\views/exports/datainfo.blade.php ENDPATH**/ ?>