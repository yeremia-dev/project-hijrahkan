<?php $__env->startSection('card-title'); ?>
    <h2 class="card-title text-muted">KPR</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('input-value'); ?>
    <input type="hidden" value="<?php echo e(base64_encode(3)); ?>" name="jenis_cicilan">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.form-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fastwork\project-hijrahkan\resources\views/form/kpr.blade.php ENDPATH**/ ?>