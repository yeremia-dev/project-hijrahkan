<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>
</head>
<body>
    <table>
        <thead>
        <tr>
            <th style="font-weight: bold">NO</th>
            <th style="font-weight: bold">JENIS CICILAN</th>
            <th style="font-weight: bold">NAMA</th>
            <th style="font-weight: bold">NOMOR TELEPHONE</th>
            <th style="font-weight: bold">EMAIL</th>
            <th style="font-weight: bold">SISA CICILAN (Rp)</th>
            <th style="font-weight: bold">BESAR CICILAN (Rp)</th>
            <th style="font-weight: bold">SISA WAKTU CICILAN</th>
            <th style="font-weight: bold">NAMA BANK</th>
        </tr>
        </thead>
        <tbody>
        <?php $no = 1 ?>
        <?php $__currentLoopData = $datausers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datauser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <?php if($datauser->id_jenis == 1): ?>
                    <td><?php echo e($jeniscicilans[0]->jenis); ?></td>
                <?php elseif($datauser->id_jenis == 2): ?>
                    <td><?php echo e($jeniscicilans[1]->jenis); ?></td>
                <?php elseif($datauser->id_jenis == 3): ?>
                    <td><?php echo e($jeniscicilans[2]->jenis); ?></td>
                <?php else: ?>
                    <td><?php echo e($jeniscicilans[3]->jenis); ?></td>
                <?php endif; ?>
                <td><?php echo e($datauser->nama); ?></td>
                <td><?php echo e($datauser->nomor_hp); ?></td>
                <td><?php echo e($datauser->email); ?></td>
                <td><?php echo e($datauser->sisa_cicilan); ?></td>
                <td><?php echo e($datauser->besar_cicilan); ?></td>
                <td><?php echo e($datauser->sisa_waktu_cicilan); ?> Bulan</td>
                <td><?php echo e($datauser->nama_bank); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\Miku\project-hijrahkan\resources\views/exports/datauser.blade.php ENDPATH**/ ?>